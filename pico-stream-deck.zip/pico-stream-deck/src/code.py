# Pico Stream Deck: 3x3 button matrix + volume knob + SSD1306 OLED
# Needs CircuitPython 9 or newer, plus these in CIRCUITPY/lib:
#   adafruit_hid, adafruit_display_text, adafruit_displayio_ssd1306.mpy
#
# Wiring:
#   Matrix rows     GP6, GP7, GP8     (diode stripe toward the row, if used)
#   Matrix columns  GP9, GP10, GP11
#   OLED            GND->GND, VDD->3V3 OUT, SCK->GP5, SDA->GP4
#   Potentiometer   outer legs->ADC_VREF and AGND, middle leg->GP26

import time
import board
import busio
import displayio
import i2cdisplaybus
import bitmaptools
import terminalio
import keypad
import analogio
import usb_hid
import adafruit_displayio_ssd1306
from adafruit_display_text import label
from adafruit_hid.keyboard import Keyboard
from adafruit_hid.keycode import Keycode
from adafruit_hid.consumer_control import ConsumerControl
from adafruit_hid.consumer_control_code import ConsumerControlCode

# ---------------- Settings ----------------
# 3x3 button matrix: button number = row * 3 + column
ROW_PINS = (board.GP6, board.GP7, board.GP8)
COLUMN_PINS = (board.GP9, board.GP10, board.GP11)

# (name shown on screen, action) - keep names to 10 characters or less.
# Action is a tuple of Keycodes (single key or combo) or a ConsumerControlCode (media key).
BUTTONS = (
    ("Scene 1", (Keycode.F13,)),
    ("Scene 2", (Keycode.F14,)),
    ("Scene 3", (Keycode.F15,)),
    ("Record", (Keycode.F16,)),
    ("Stream", (Keycode.F17,)),
    ("Mic Mute", (Keycode.F18,)),
    ("Clip", (Keycode.F19,)),
    ("Play/Pause", ConsumerControlCode.PLAY_PAUSE),
    ("Mute", ConsumerControlCode.MUTE),
)

VOL_STEPS = 50        # Windows: 50 (each step is 2%). macOS: 16.
SYNC_ON_BOOT = True   # set the computer's volume to match the knob at startup
OLED_ADDRESS = 0x3C   # try 0x3D if the screen stays blank

# ---------------- Hardware ----------------
displayio.release_displays()
i2c = busio.I2C(scl=board.GP5, sda=board.GP4, frequency=400_000)
bus = i2cdisplaybus.I2CDisplayBus(i2c, device_address=OLED_ADDRESS)
display = adafruit_displayio_ssd1306.SSD1306(bus, width=128, height=64)

# If you use diodes, put the striped (cathode) end toward the row wire.
buttons = keypad.KeyMatrix(ROW_PINS, COLUMN_PINS, columns_to_anodes=True)
knob = analogio.AnalogIn(board.GP26)
keyboard = Keyboard(usb_hid.devices)
media = ConsumerControl(usb_hid.devices)

# ---------------- Screen layout ----------------
# On this module the top 16 pixel rows are yellow and the rest are blue.
screen = displayio.Group()
display.root_group = screen
display.auto_refresh = False   # only update the screen when we call display.refresh()

header = label.Label(terminalio.FONT, text="STREAM DECK", color=0xFFFFFF)
header.anchor_point = (0.5, 0.5)
header.anchored_position = (64, 7)          # yellow strip
screen.append(header)

action_text = label.Label(terminalio.FONT, text="Ready", color=0xFFFFFF, scale=2)
action_text.anchor_point = (0.5, 0.5)
action_text.anchored_position = (64, 32)    # blue area
screen.append(action_text)

vol_text = label.Label(terminalio.FONT, text="", color=0xFFFFFF)
vol_text.anchor_point = (0, 0.5)
vol_text.anchored_position = (0, 56)
screen.append(vol_text)

BAR_X, BAR_W, BAR_H = 30, 98, 9
bar_bitmap = displayio.Bitmap(BAR_W, BAR_H, 2)
palette = displayio.Palette(2)
palette[0] = 0x000000
palette[1] = 0xFFFFFF
screen.append(displayio.TileGrid(bar_bitmap, pixel_shader=palette, x=BAR_X, y=52))

# Draw the bar's outline once; after this only the inside is ever changed
bitmaptools.fill_region(bar_bitmap, 0, 0, BAR_W, BAR_H, 1)
bitmaptools.fill_region(bar_bitmap, 1, 1, BAR_W - 1, BAR_H - 1, 0)


def show_volume(level):
    vol_text.text = "{}%".format(level * 100 // VOL_STEPS)
    filled = 2 + (BAR_W - 4) * level // VOL_STEPS
    if filled > 2:
        bitmaptools.fill_region(bar_bitmap, 2, 2, filled, BAR_H - 2, 1)       # lit part
    if filled < BAR_W - 2:
        bitmaptools.fill_region(bar_bitmap, filled, 2, BAR_W - 2, BAR_H - 2, 0)  # empty part


# ---------------- Knob ----------------
def read_knob(samples=16):
    total = 0
    for _ in range(samples):
        total += knob.value
    return total / samples / 65535   # 0.0 .. 1.0


def knob_level(current):
    pos = read_knob() * VOL_STEPS
    # Hysteresis: ignore jitter until the knob is clearly past the next step
    if abs(pos - current) > 0.7:
        return max(0, min(VOL_STEPS, round(pos)))
    return current


def nudge_volume(steps):
    code = (ConsumerControlCode.VOLUME_INCREMENT if steps > 0
            else ConsumerControlCode.VOLUME_DECREMENT)
    for _ in range(abs(steps)):
        media.send(code)


# ---------------- Startup ----------------
level = round(read_knob() * VOL_STEPS)
if SYNC_ON_BOOT:
    time.sleep(1)                     # let the computer finish setting up USB
    nudge_volume(-(VOL_STEPS + 5))    # drive volume to 0...
    nudge_volume(level)               # ...then up to where the knob is
show_volume(level)
display.refresh()
screen_changed = False

# ---------------- Main loop ----------------
while True:
    event = buttons.events.get()
    if event:
        name, act = BUTTONS[event.key_number]
        if isinstance(act, tuple):
            if event.pressed:
                keyboard.press(*act)
            else:
                keyboard.release(*act)
        elif event.pressed:
            media.send(act)
        if event.pressed:
            action_text.text = name
            screen_changed = True

    new_level = knob_level(level)
    if new_level != level:
        # Overshoot a little at the ends so turning fully left/right re-syncs
        extra = -5 if new_level == 0 else (5 if new_level == VOL_STEPS else 0)
        nudge_volume(new_level - level + extra)
        level = new_level
        show_volume(level)
        screen_changed = True

    if screen_changed:
        display.refresh()   # push the finished frame in one go
        screen_changed = False

    time.sleep(0.005)
