# 3x3 button matrix test (CircuitPython)
# Rows: GP6, GP7, GP8   Columns: GP9, GP10, GP11
# Diodes (if used): striped end toward the row wire.

import board
import digitalio
import keypad

ROW_PINS = (board.GP6, board.GP7, board.GP8)
COLUMN_PINS = (board.GP9, board.GP10, board.GP11)

buttons = keypad.KeyMatrix(ROW_PINS, COLUMN_PINS, columns_to_anodes=True)
led = digitalio.DigitalInOut(board.LED)
led.direction = digitalio.Direction.OUTPUT
held = set()

print("Matrix test ready - press any button")

while True:
    event = buttons.events.get()
    if event:
        n = event.key_number
        action = "pressed" if event.pressed else "released"
        print("Button {} (row {}, col {}) {}".format(n + 1, n // 3 + 1, n % 3 + 1, action))
        if event.pressed:
            held.add(n)
        else:
            held.discard(n)
        led.value = bool(held)    # onboard LED lights while any button is held
