# Single button test (CircuitPython). Run from Thonny, or save as code.py on CIRCUITPY.
# Wire one leg of the button to GP15 (pin 20) and the opposite leg to GND (pin 18).

import board
import digitalio
import keypad

button = keypad.Keys((board.GP15,), value_when_pressed=False, pull=True)
led = digitalio.DigitalInOut(board.LED)
led.direction = digitalio.Direction.OUTPUT

print("Ready - press the button")

while True:
    event = button.events.get()
    if event:
        print("Pressed" if event.pressed else "Released")
        led.value = event.pressed
